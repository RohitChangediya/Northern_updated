<?php 

print_r($_SERVER);
echo "http://".$_SERVER['SERVER_NAME'];



?>